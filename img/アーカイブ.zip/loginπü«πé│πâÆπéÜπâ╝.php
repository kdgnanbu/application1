<?php

require_once('config.php');

session_start();
//POSTのvalidate
if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
  echo '入力された値が不正です。';
  return false;
}
//DB内でPOSTされたメールアドレスを検索
try {
  $pdo = new PDO(DSN, DB_USER, DB_PASS);
  $stmt = $pdo->prepare('select * from member_m where email = ?');
  $stmt->execute([$_POST['email']]);
  $stmt = $pdo->prepare('select * from member_m where password = ?');
  $stmt->execute([$_POST['password']]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (\Exception $e) {
  echo $e->getMessage() . PHP_EOL;
}
//emailがDB内に存在しているか確認
if (!isset($row['email'])) {
  echo 'メールアドレスが間違っているかアカウントが存在しません。';
  return false;
}
//パスワード確認後sessionにメールアドレスを渡す
if (!isset($row['password'])) {
    echo 'パスワードが間違っています';
    return false;
} else {
  echo 'ログインしました';
  return false;
}
?>
